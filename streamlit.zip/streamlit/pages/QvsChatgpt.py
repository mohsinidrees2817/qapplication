import streamlit as st

st.title("Q vs ChatGPT")